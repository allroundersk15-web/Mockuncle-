# MOCKUNCLE + Gemini AI — Netlify Manual Deploy

यह पैकेज आपकी सबसे हाल की `MOCKUNCLE_blue_theme_polish.html` फाइल पर आधारित है। मौजूदा mock-test, IndexedDB question library, PDF import, backup/restore और UI को बनाए रखते हुए Gemini integration को Netlify Functions से जोड़ा गया है।

## इसमें क्या जुड़ा है
- मौजूदा Gemini AI panel अब `/.netlify/functions/gemini` को call करता है।
- AI Chat, question explanation और original MCQ generation।
- PDF mode: theory PDF से नए MCQ और existing MCQ PDF से प्रश्न निकालना।
- PDF.js से selectable text extraction। जिन pages पर text layer नहीं मिलता, उन पर Tesseract.js (English + Hindi) browser OCR fallback।
- Gemini का structured JSON output मौजूदा Extracted Questions review screen में import होता है। वहाँ हर question/option/answer review और edit करके existing `Save reviewed questions` flow से library में save किया जाता है।
- API key केवल Netlify Function environment में रहती है; HTML/JavaScript में नहीं।
- Function में basic per-IP rate limiting, input limits और generic error responses।

## Folder structure

```text
MOCKUNCLE_Netlify_Gemini/
├── netlify.toml
├── package.json
├── README_HI.md
├── public/
│   └── index.html
└── netlify/
    └── functions/
        └── gemini.mjs
```

## जरूरी सीमाएँ
- PDF को browser में text/OCR में बदला जाता है; raw PDF या PDF contents की OCR text Gemini API को भेजी जाती है।
- PDF file limit इस build में 25 MB है। OCR fallback अधिकतम पहले 40 pages पर चलता है; बड़े दस्तावेज़ को छोटे भागों में बाँटें। Selectable-text PDF के लिए text extraction 90,000 characters तक सीमित है।
- OCR quality scan clarity, language, columns, equations और diagrams पर निर्भर है। गणितीय सूत्र/जटिल tables manually verify करें।
- Gemini-generated answer keys को save/mock में इस्तेमाल करने से पहले verify करना जरूरी है। Unsupported answers को blank/verify status में रखा जाता है।
- Function request rate limit एक warm instance पर basic abuse protection है, full user authentication/quota system नहीं। Public high-traffic deployment के लिए authentication, stricter quota, logging and monitoring जोड़ें।
- AI features केवल deployed Netlify site या `netlify dev` के जरिए चलेंगे; `file://` से HTML खोलने पर backend call काम नहीं करेगी।

## 1. Netlify API key जोड़ें

1. Netlify Dashboard → अपनी मौजूदा MOCKUNCLE site खोलें।
2. Project configuration / Environment variables में जाएँ।
3. नया variable बनाएँ:
   - Key: `GEMINI_API_KEY`
   - Value: आपकी Google AI Studio API key
   - Scope: Functions (अगर scope चुनने का विकल्प उपलब्ध हो)
   - Context: Production (या All deploy contexts)
4. Save करें। API key को इस ZIP, HTML, JavaScript या chat में न डालें।

Optional variable: `GEMINI_MODEL=gemini-2.5-flash` (default यही है)।

## 2. Windows पर deploy करना (GitHub की जरूरत नहीं)

1. Node.js 20 या नया install करें: https://nodejs.org/en/download
2. ZIP extract करें।
3. उस extracted `MOCKUNCLE_Netlify_Gemini` folder में File Explorer address bar में `cmd` लिखकर Enter दबाएँ।
4. Command Prompt में चलाएँ:

```bash
npm install -g netlify-cli
netlify login
netlify link
```

`netlify link` में अपनी पहले से बनी MOCKUNCLE site चुनें। नई site create न करें।

5. Draft/preview deployment करें:

```bash
netlify deploy
```

Netlify CLI `netlify.toml` से `public` publish folder और `netlify/functions` functions folder पढ़ेगा। Preview URL पर नीचे दिए tests करें।

6. सब सही हो तो live production deployment करें:

```bash
netlify deploy --prod
```

**महत्वपूर्ण:** केवल `public` folder को Netlify Drop पर drag-and-drop करने से Functions deploy नहीं होंगी। इस package के लिए Netlify CLI deployment इस्तेमाल करें। यह manual deployment ही है; GitHub जरूरी नहीं।

## 3. Local test (वैकल्पिक)

Project folder में:

```bash
netlify dev
```

पहले Netlify Dashboard में API key save करें। फिर local site CLI द्वारा दिखाए गए URL पर खोलें।

## 4. Health check

Deploy के बाद browser में खोलें:

```text
https://YOUR-SITE.netlify.app/.netlify/functions/gemini
```

Expected response में `ok: true` और `configured: true` होना चाहिए। इसमें API key value कभी नहीं लौटती।

## 5. वेबसाइट पर इस्तेमाल

1. MOCKUNCLE dashboard पर Gemini AI खोलें।
2. AI feature में `AI teacher / chatbot`, `Answer explanation`, `SSC / Railway question generator` या `PDF to MCQs` चुनें।
3. PDF mode में Theory, existing MCQ या scanned PDF चुनें।
4. Questions count, exam और subject चुनें; Run Gemini AI दबाएँ।
5. Generated questions के लिए `Add generated questions to MOCKUNCLE review` दबाएँ।
6. मौजूदा Extracted Questions review screen में question, चार options, answer और explanation जाँचें। Hindi text उपलब्ध हो तो जाँचें।
7. Test title भरें और `Save reviewed questions` दबाएँ। अब प्रश्न आपकी existing question library में होंगे।

## Troubleshooting
- `GEMINI_API_KEY` not configured: Netlify Environment Variables में key और Functions scope जाँचें, फिर redeploy करें।
- 429/quota: Google AI Studio project/model quota जाँचें और कुछ देर बाद retry करें।
- OCR library load error: browser internet connection/CDN access जाँचें।
- PDF text unreadable: PDF split करें, scan quality बेहतर करें या OCR language/diagram output manually verify करें।
- Function 404: `netlify.toml` root folder में है और `netlify deploy` उसी project root से चलाया गया है, यह जाँचें।

Official docs:
- Netlify Functions: https://docs.netlify.com/build/functions/get-started/
- Netlify CLI manual deploy: https://docs.netlify.com/api-and-cli-guides/cli-guides/get-started-with-cli/
- Netlify environment variables: https://docs.netlify.com/build/functions/environment-variables/
- Gemini API: https://ai.google.dev/gemini-api/docs
