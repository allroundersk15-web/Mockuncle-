const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const MAX_TEXT = 90000;
const MAX_PROMPT = 12000;
const WINDOW_MS = 60_000;
const MAX_REQUESTS = 15;
const requests = new Map();

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff'
    }
  });
}
function clean(value, max) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}
function rateLimited(ip) {
  const now = Date.now();
  const recent = (requests.get(ip) || []).filter(t => now - t < WINDOW_MS);
  if (recent.length >= MAX_REQUESTS) return true;
  recent.push(now);
  requests.set(ip, recent);
  if (requests.size > 500) {
    for (const [key, times] of requests) if (!times.some(t => now - t < WINDOW_MS)) requests.delete(key);
  }
  return false;
}
function buildPrompt({ mode, exam, subject, count, prompt, pdfText, language, difficulty }) {
  const base = `You are MOCKUNCLE's careful competitive-exam tutor. Exam: ${exam}. Subject: ${subject}. Be accurate, clear and age-appropriate. Never claim generated questions are official or previous-year questions. If the source does not support an answer, set answer to null and answerStatus to "verify". Language preference: ${language}. Difficulty: ${difficulty}.`;
  if (mode === 'chat' || mode === 'explain' || mode === 'improve') {
    if (mode === 'explain') return `${base}\nExplain the following question. State the likely correct option, show the reasoning step by step, and briefly explain why each other option is incorrect. Clearly flag uncertainty.\n\n${prompt}`;
    if (mode === 'improve') return `${base}\nReview and improve this question without changing its intended concept. Return a revised question, four options, answer only when supported, explanation, and any ambiguity.\n\n${prompt}`;
    return `${base}\nAct as a patient exam tutor. Answer the student's question clearly, show calculation steps where relevant, and use examples.\n\n${prompt}`;
  }
  if (mode === 'generate') return `${base}\nCreate exactly ${count} original exam-style MCQs based on this instruction: ${prompt || 'Create a balanced mixed practice set.'}. Return ONLY valid JSON in this shape: {"questions":[{"q":"question","hiQ":"Hindi translation or empty","options":["A","B","C","D"],"hiOptions":["...","...","...","..."],"answer":0,"answerStatus":"verified|verify","explanation":"...","subject":"...","difficulty":"easy|medium|hard","pageNumber":null}]}. answer must be 0,1,2,3 or null. Keep answer and options consistent.`;
  if (mode === 'pdf') return `${base}\nRead the supplied PDF text. It may contain THEORY ONLY, existing MCQs, tables or mixed material. If it contains MCQs, extract them faithfully and do not silently rewrite them. If it contains theory, create up to ${count} useful original MCQs strictly grounded in the theory. Include exactly four options when possible, a Hindi translation when requested, correct answer, concise explanation, subject, difficulty and source page number. Do not invent facts. Skip incomplete/unanswerable items or set answer=null and answerStatus="verify". Avoid duplicates. Return ONLY valid JSON in this shape: {"questions":[{"q":"question","hiQ":"Hindi translation or empty","options":["A","B","C","D"],"hiOptions":["...","...","...","..."],"answer":0,"answerStatus":"verified|verify","explanation":"...","subject":"...","difficulty":"easy|medium|hard","pageNumber":1}]}. answer must be 0,1,2,3 or null.\n\nPDF CONTENT:\n${pdfText}`;
  throw new Error('Unsupported AI mode.');
}

export default async (req, context) => {
  if (req.method === 'GET') return json({ ok: true, service: 'MOCKUNCLE Gemini', configured: Boolean(process.env.GEMINI_API_KEY), model: MODEL });
  if (req.method !== 'POST') return json({ error: 'Method not allowed.' }, 405);
  const ip = context?.ip || req.headers.get('x-nf-client-connection-ip') || 'unknown';
  if (rateLimited(ip)) return json({ error: 'Too many AI requests. Please wait one minute and try again.' }, 429);
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return json({ error: 'Gemini is not configured. Add GEMINI_API_KEY to Netlify environment variables with Functions scope.' }, 503);

  try {
    const body = await req.json();
    const mode = clean(body?.mode, 24);
    const exam = clean(body?.exam, 80) || 'General';
    const subject = clean(body?.subject, 80) || 'Mixed';
    const count = Math.max(1, Math.min(50, Number(body?.count) || 10));
    const prompt = clean(body?.prompt, MAX_PROMPT);
    const pdfText = clean(body?.pdfText, MAX_TEXT);
    const language = clean(body?.language, 40) || 'Hindi + English';
    const difficulty = clean(body?.difficulty, 30) || 'Mixed';
    if (!['chat', 'explain', 'improve', 'generate', 'pdf'].includes(mode)) return json({ error: 'Unknown Gemini feature.' }, 400);
    if (mode === 'pdf' && !pdfText) return json({ error: 'No readable PDF text received. Try OCR or a text-based PDF.' }, 400);
    if (!['pdf', 'generate'].includes(mode) && !prompt) return json({ error: 'Please enter a question or instruction.' }, 400);
    const contents = buildPrompt({ mode, exam, subject, count, prompt, pdfText, language, difficulty });
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent?key=${encodeURIComponent(apiKey)}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: contents }] }],
        ...(mode === 'pdf' || mode === 'generate' ? { generationConfig: { responseMimeType: 'application/json', temperature: 0.25 } } : {})
      })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const msg = data?.error?.message || `Gemini API returned ${response.status}.`;
      console.error('Gemini API error:', response.status, msg);
      return json({ error: response.status === 429 ? 'Gemini quota/rate limit reached. Check AI Studio quota or try later.' : 'Gemini request failed. Check the API key, model access and Netlify function logs.' }, response.status === 429 ? 429 : 502);
    }
    const text = (data?.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('').trim();
    if (!text) return json({ error: 'Gemini returned an empty response. Please try again.' }, 502);
    if (mode === 'pdf' || mode === 'generate') {
      let parsed;
      try { parsed = JSON.parse(text); } catch { return json({ error: 'Gemini response was not valid JSON. Please retry with fewer questions or fewer PDF pages.' }, 502); }
      if (!parsed || !Array.isArray(parsed.questions)) return json({ error: 'Gemini did not return a valid question list.' }, 502);
      parsed.questions = parsed.questions.slice(0, count).map(q => ({
        q: clean(q?.q, 3000), hiQ: clean(q?.hiQ, 3000),
        options: Array.isArray(q?.options) ? q.options.slice(0, 4).map(x => clean(x, 1200)) : [],
        hiOptions: Array.isArray(q?.hiOptions) ? q.hiOptions.slice(0, 4).map(x => clean(x, 1200)) : [],
        answer: [0, 1, 2, 3].includes(Number(q?.answer)) ? Number(q.answer) : null,
        answerStatus: clean(q?.answerStatus, 20) || 'verify',
        explanation: clean(q?.explanation, 4000), subject: clean(q?.subject, 80) || subject,
        difficulty: clean(q?.difficulty, 20), pageNumber: Number.isFinite(Number(q?.pageNumber)) ? Number(q.pageNumber) : null
      })).filter(q => q.q && q.options.length === 4 && q.options.every(Boolean));
      return json({ mode, model: MODEL, questions: parsed.questions, text: JSON.stringify({ questions: parsed.questions }, null, 2) });
    }
    return json({ mode, model: MODEL, text });
  } catch (error) {
    console.error('MOCKUNCLE Gemini function error:', error?.message || error);
    return json({ error: 'Could not process this request. Check the PDF size/content and try again.' }, 500);
  }
};
